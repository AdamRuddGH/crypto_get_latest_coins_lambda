"""Top-level package for Super Json Normalize with Array Ultra."""

__author__ = """Adam Rudd"""
__email__ = 'Adam@adamrudd.net'
__version__ = '0.1.0'
